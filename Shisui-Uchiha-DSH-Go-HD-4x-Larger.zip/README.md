# Shisui Uchiha — DSH-Go HD Larger Edition

- Based on the working Native Pet Pack schema 1 package.
- Preserves all HD (2x) PNG animation sheets and animation timing.
- Keeps every animation frame box and `frameW = box.w × scale` / `frameH = box.h × scale` relationship unchanged.
- Adjusts `contentBox.h` from 181 to 120 so DSH-Go's Large tier renders the character at approximately 1.5× the previous body height (about 60dp instead of 40dp).
- Keeps canvas, anchor, and hitboxes unchanged.

Import this ZIP from Pets → Import, then select Shisui Uchiha and keep Size = Large.
